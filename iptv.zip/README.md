Roku IPTV app for telstra tv, i ripped it from somewhere changed couple things theres even a playlist go ham

chuck ur telstra roku box in developer mode and go to its IP address in browser